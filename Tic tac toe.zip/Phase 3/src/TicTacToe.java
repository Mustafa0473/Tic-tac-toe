class TicTacToe {
    char[][] grid;
    Player player_1;
    Player player_2;

    public TicTacToe() {
        initializeGrid();

        this.player_1 = new Player("Player 1", 'O');
        this.player_2 = new Player("Player 2", 'X');
    }

    // Initialize the grid to empty spaces
    public void initializeGrid() {
        grid = new char[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                grid[i][j] = ' ';
            }
        }
    }

    // Make a move in the specified row and column after checking valid move
    public boolean makeMove(int row, int col, char sign) {
        if (grid[row][col] == ' ') {
            grid[row][col] = sign;
            return true;
        }
        return false;
    }

    // Check if the current player has won
    public boolean checkWin(char sign) {
        // Check rows, columns, and diagonals for a win
        for (int i = 0; i < 3; i++) {
            if (grid[i][0] == sign && grid[i][1] == sign && grid[i][2] == sign) return true;
            if (grid[0][i] == sign && grid[1][i] == sign && grid[2][i] == sign) return true;
        }
        if (grid[0][0] == sign && grid[1][1] == sign && grid[2][2] == sign) return true;
        if (grid[0][2] == sign && grid[1][1] == sign && grid[2][0] == sign) return true;
        return false;
    }

    // Check if the grid is full
    public boolean isGridFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (grid[i][j] == ' ')
                    return false;
            }
        }
        return true;
    }

}
