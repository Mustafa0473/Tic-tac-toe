import javax.swing.*;
import java.awt.*;

class TicTacToeUI extends JFrame {
    private TicTacToe game;
    private JButton[][] buttons = new JButton[3][3];
    private JLabel status_label = new JLabel("Player 1's Turn (O)");
    private boolean player_1_turn = true;

    public TicTacToeUI() {
        game = new TicTacToe();

        setupUI();
    }

    public void setupUI() {
        setTitle("Tic Tac Toe");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel gamePanel = new JPanel(new GridLayout(3, 3));
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new JButton(" ");
                buttons[i][j].setFont(new Font("Arial", Font.PLAIN, 40));
                buttons[i][j].setBackground(Color.WHITE); // Default background color
                final int row = i, col = j;
                buttons[i][j].addActionListener(e -> handleButtonClick(row, col));
                gamePanel.add(buttons[i][j]);
            }
        }

        add(gamePanel, BorderLayout.CENTER);

        status_label.setHorizontalAlignment(SwingConstants.CENTER);
        status_label.setFont(new Font("Arial", Font.BOLD, 16));
        add(status_label, BorderLayout.SOUTH);
    }

    public  void handleButtonClick(int row, int col) {
        Player currentPlayer = player_1_turn ? game.player_1.getPlayer() : game.player_2.getPlayer();
        char currentSign = currentPlayer.getSign();

        if (game.makeMove(row, col, currentSign)) {
            // Set text and background color based on the current player
            buttons[row][col].setText(String.valueOf(currentSign));
            buttons[row][col].setEnabled(false);
            buttons[row][col].setBackground(player_1_turn ? Color.decode("#CC004C") : Color.decode("#0DB14B"));
            buttons[row][col].setForeground(Color.WHITE); // Ensure the text is readable

            if (game.checkWin(currentSign)) {
                status_label.setText(currentPlayer.getName() + " Wins!");
                disableAllButtons();
            } else if (game.isGridFull()) {
                status_label.setText("It's a Draw!");
            } else {
                player_1_turn = !player_1_turn;
                status_label.setText(player_1_turn ? "Player 1's Turn (O)" : "Player 2's Turn (X)");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid Move! Try again.");
        }
    }

    public void disableAllButtons() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setEnabled(false);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TicTacToeUI game = new TicTacToeUI();
            game.setVisible(true);
        });
    }
}
